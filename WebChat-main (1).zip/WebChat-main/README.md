# WebChat
It's a web based chat app made using JavaScript library socket.io

![webchat](https://user-images.githubusercontent.com/64949957/124345920-7b7c1080-dbf9-11eb-8d26-2c7c03720a31.PNG)
